#!/bin/sh
set -e
sudo su
apt update
apt install openjdk-8-jdk
tar -xzvf hadoop-2.6.5.tar.gz -C /usr/local
ssh-keygen -A
ssh-keygen -t rsa -P '' -f ~/.ssh/id_rsa
cat ~/.ssh/id_rsa.pub >> ~/.ssh/authorized_keys
chmod 0600 ~/.ssh/authorized_keys
sudo service ssh restart
cat << EOT >> ~/.bashrc
#HADOOP VARIABLES START
export JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64
export HADOOP_INSTALL=/usr/local/hadoop
export PATH=$PATH:$HADOOP_INSTALL/bin
export PATH=$PATH:$HADOOP_INSTALL/sbin
export HADOOP_MAPRED_HOME=$HADOOP_INSTALL
export HADOOP_COMMON_HOME=$HADOOP_INSTALL
export HADOOP_HDFS_HOME=$HADOOP_INSTALL
export YARN_HOME=$HADOOP_INSTALL
export HADOOP_COMMON_LIB_NATIVE_DIR=$HADOOP_INSTALL/lib/native
export HADOOP_OPTS="-Djava.library.path=$HADOOP_INSTALL/lib"
#HADOOP VARIABLES END
EOT
source ~/.bashrc
echo "export JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64" >> $HADOOP_INSTALL/etc/hadoop/hadoop-env.sh
mkdir -p /app/hadoop/tmp
chmod 777 -R /app/hadoop/tmp
cp core-site.xml $HADOOP_INSTALL/etc/hadoop/
cp mapred-site.xml $HADOOP_INSTALL/etc/hadoop/
cp hdfs-site.xml $HADOOP_INSTALL/etc/hadoop/
mkdir /usr/local/hadoop_store/hdfs
chmod 777 -R /usr/local/hadoop_store
hadoop namenode -format
jps
start-yarn.sh
start-dfs.sh
jps
echo "HADOOP INSTALLATION COMPLETE"
